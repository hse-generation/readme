import scrapy

class Book_scrapy(scrapy.Spider):
    name = 'gorod'

    url = ['https://www.chitai-gorod.ru/catalog/books/detektiv_boyevik_triller-9685/?sort=name&available=1&page=1',
           'https://www.chitai-gorod.ru/catalog/books/detektiv_boyevik_triller-9685/?sort=name&available=1&page=2',  # детективы
           'https://www.chitai-gorod.ru/catalog/books/detektiv_boyevik_triller-9685/?sort=name&available=1&page=3',
           'https://www.chitai-gorod.ru/catalog/books/detektiv_boyevik_triller-9685/?sort=name&available=1&page=4',

           'https://www.chitai-gorod.ru/catalog/books/klassicheskaya_i_sovremennaya_proza-9665/?available=1&page=1',
           'https://www.chitai-gorod.ru/catalog/books/klassicheskaya_i_sovremennaya_proza-9665/?available=1&page=2',  # классика
           'https://www.chitai-gorod.ru/catalog/books/klassicheskaya_i_sovremennaya_proza-9665/?available=1&page=3',
           'https://www.chitai-gorod.ru/catalog/books/klassicheskaya_i_sovremennaya_proza-9665/?available=1&page=4',

           'https://www.chitai-gorod.ru/search/result/?q=%D1%80%D0%BE%D0%BC%D0%B0%D0%BD&sort=_score&order=desc&page=1',
           'https://www.chitai-gorod.ru/search/result/?q=%D1%80%D0%BE%D0%BC%D0%B0%D0%BD&sort=_score&order=desc&page=2',  # романы
           'https://www.chitai-gorod.ru/search/result/?q=%D1%80%D0%BE%D0%BC%D0%B0%D0%BD&sort=_score&order=desc&page=3',
           'https://www.chitai-gorod.ru/search/result/?q=%D1%80%D0%BE%D0%BC%D0%B0%D0%BD&sort=_score&order=desc&page=4',

           'https://www.chitai-gorod.ru/catalog/bestsell/#%D0%9A%D0%BB%D0%B0%D1%81%D1%81%D0%B8%D1%87%D0%B5%D1%81%D0%BA%D0%B0%D1%8F%20%D0%B8%20%D1%81%D0%BE%D0%B2%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BD%D0%B0%D1%8F%20%D0%BF%D1%80%D0%BE%D0%B7%D0%B0',
           'https://www.chitai-gorod.ru/catalog/bestsell/#%D0%94%D0%B5%D1%82%D0%B5%D0%BA%D1%82%D0%B8%D0%B2',  # best
           'https://www.chitai-gorod.ru/catalog/bestsell/#%D0%A4%D0%B0%D0%BD%D1%82%D0%B0%D1%81%D1%82%D0%B8%D0%BA%D0%B0',
           'https://www.chitai-gorod.ru/catalog/bestsell/#%D0%A4%D0%B8%D0%BB%D0%BE%D1%81%D0%BE%D1%84%D0%B8%D1%8F%20%D0%B8%20%D1%80%D0%B5%D0%BB%D0%B8%D0%B3%D0%B8%D1%8F']

    def start_requests(self):
        for link in self.url:
            yield scrapy.Request(link, self.parse_books)

    def parse_books(self, response):
        urls = response.css('a.product-card__link.js-watch-productlink::attr(href)').getall()
        for i in range(len(urls)):
            urls[i] = 'https://www.chitai-gorod.ru' + urls[i]
        for page in urls:
            yield scrapy.Request(page, self.parse_book)

    def parse_book(self, response):

        return {
            'book_url': response.request.ur[],
            'name': response.css('h1.product__title::text').get().strip(),
            'author': response.css('a.link.product__author::text').get().strip(),
            'genres': response.css('ul.breadcrumbs li.breadcrumbs__item span::text').getall()[-2],
            'score': response.css('span.js__rating_count::text').get(),
            'pages': response.xpath('//div[@itemprop="numberOfPages"]/text()').extract()[0].strip(),
            'description': response.xpath('//div[@itemprop="description"]/text()').extract()[0].strip(),
            'cover link':  response.xpath('//div[@data-media="photo"]/img/@data-src').extract()[0]
        }
